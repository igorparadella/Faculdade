package com.example.midiaplayer

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.text.TextUtils
import java.io.IOException


data class Music(val title: String, val artist: String, val uri: Uri)

class MainActivity : AppCompatActivity() {

    private lateinit var musicListContainer: LinearLayout
    private lateinit var miniPlayer: LinearLayout
    private lateinit var nowPlayingText: TextView
    private lateinit var playPauseButton: TextView
    private lateinit var prevButton: TextView
    private lateinit var nextButton: TextView

    private var mediaPlayer: MediaPlayer? = null
    private var currentMusicUri: Uri? = null
    private var currentMusic: Music? = null
    private var isPaused = false
    private var currentPlayingIconView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        musicListContainer = findViewById(R.id.musicListContainer)

        // Referências do mini player
        miniPlayer = findViewById(R.id.miniPlayer)
        nowPlayingText = findViewById(R.id.nowPlayingText)
        playPauseButton = findViewById(R.id.playPauseButton)
        prevButton = findViewById(R.id.prevButton)
        nextButton = findViewById(R.id.nextButton)

        // Controles do mini player
        playPauseButton.setOnClickListener {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.pause()
                playPauseButton.text = "▶"
            } else {
                mediaPlayer?.start()
                playPauseButton.text = "⏸︎"
            }
        }

        prevButton.setOnClickListener {
            Toast.makeText(this, "Função anterior não implementada", Toast.LENGTH_SHORT).show()
        }

        nextButton.setOnClickListener {
            Toast.makeText(this, "Função próxima não implementada", Toast.LENGTH_SHORT).show()
        }

        checkPermissionsAndLoadMusic()
    }

    private fun checkPermissionsAndLoadMusic() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_AUDIO
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadMusic()
        } else {
            requestPermissionLauncher.launch(permission)
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                loadMusic()
            } else {
                Toast.makeText(this, "Permissão negada para acessar músicas", Toast.LENGTH_SHORT).show()
            }
        }

    private fun loadMusic() {
        val musicList = mutableListOf<Music>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        val cursor = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            MediaStore.Audio.Media.TITLE + " ASC"
        )

        cursor?.use {
            val idIndex = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleIndex = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistIndex = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)

            while (it.moveToNext()) {
                val id = it.getLong(idIndex)
                val title = it.getString(titleIndex)
                val artist = it.getString(artistIndex)

                val contentUri = ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    id
                )

                musicList.add(Music(title, artist, contentUri))
            }
        }

        displayMusicList(musicList)
    }

    private fun displayMusicList(musicList: List<Music>) {
        for (music in musicList) {
            val musicItemLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(20, 20, 20, 20)
                setBackgroundColor(0xFFE0E0E0.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, 0, 0, 16)
                }
            }

            val iconView = TextView(this).apply {
                text = "▶︎"
                textSize = 20f
                setPadding(0, 0, 20, 0)
            }

            val titleView = TextView(this).apply {
                text = "${music.title} - ${music.artist}"
                textSize = 16f
                setTextColor(0xFF000000.toInt())
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            musicItemLayout.addView(iconView)
            musicItemLayout.addView(titleView)

            musicItemLayout.setOnClickListener {
                if (mediaPlayer?.isPlaying == true && currentMusicUri == music.uri) {
                    mediaPlayer?.pause()
                    iconView.text = "▶︎"
                    playPauseButton.text = "▶"
                    Toast.makeText(this, "⏸︎ Pausado: ${music.title}", Toast.LENGTH_SHORT).show()
                } else {
                    playMusic(music)
                    currentPlayingIconView?.text = "▶︎"
                    iconView.text = "⏸︎"
                    currentPlayingIconView = iconView
                }
            }

            musicListContainer.addView(musicItemLayout)
        }

        if (musicList.isEmpty()) {
            Toast.makeText(this, "Nenhuma música encontrada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun playMusic(music: Music) {
        try {
            mediaPlayer?.release()

            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, music.uri)
                prepare()
                start()
            }

            currentMusicUri = music.uri
            currentMusic = music

            // Atualiza mini player
            miniPlayer.visibility = View.VISIBLE
            nowPlayingText.text = "Agora tocando: ${music.title} - ${music.artist}"
            playPauseButton.text = "⏸︎"

        } catch (e: IOException) {
            Toast.makeText(this, "Erro ao tocar: ${music.title}", Toast.LENGTH_SHORT).show()
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
